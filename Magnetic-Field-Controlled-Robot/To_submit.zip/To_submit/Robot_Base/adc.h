void initADC(void);
int readADC(unsigned int channel);
